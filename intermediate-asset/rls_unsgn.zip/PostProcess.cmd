@echo off

setlocal
set "SQLServer=%~1"
set "Database=%~2"
set "ImportPath=%~3"
set "EncryptConnection=%~4"
set "TrustServerCertificate=%~5"

rem adding +++ so they can be used as a line separator by the code
@echo %date% %time% parameters: %SQLServer% %Database% %ImportPath% +++


if not defined SQLServer goto usage
if not defined Database goto usage
if not defined ImportPath goto usage


@echo %date% %time% SQL Nexus PostProcessing +++

rem Build optional sqlcmd encryption options (compatible with all sqlcmd versions)
set "SQLCMD_ENCRYPTION_OPTS="
if /i "%EncryptConnection%"=="true" set "SQLCMD_ENCRYPTION_OPTS=%SQLCMD_ENCRYPTION_OPTS% -N"
if /i "%TrustServerCertificate%"=="true" set "SQLCMD_ENCRYPTION_OPTS=%SQLCMD_ENCRYPTION_OPTS% -C"

@echo %date% %time% Creating tblPlansTemp +++
sqlcmd.exe -S"%SQLServer%" -E -d"%Database%" %SQLCMD_ENCRYPTION_OPTS% -Q"create table tblPlansTemp (sqlplan xml)"

@echo %date% %time% Inserting into tblPlansTemp +++
for /f "delims=" %%j in ('dir /b "%ImportPath%\*.sqlplan" 2^>nul') do sqlcmd.exe -S"%SQLServer%" -E -d"%Database%" %SQLCMD_ENCRYPTION_OPTS% -Q"insert into tblPlansTemp select cast(cast(BulkColumn as varchar(max)) as xml) sqlplan from openrowset (bulk '%ImportPath%\%%j', single_blob) as doc"

@echo %date% %time% Calling SQLNexus_PostProcessing.sql +++

@echo %date% %time% sqlcmd parameters: %SQLServer% %Database% %SQLCMD_ENCRYPTION_OPTS% +++

sqlcmd.exe -S"%SQLServer%" -E -d"%Database%" %SQLCMD_ENCRYPTION_OPTS% -iSQLNexus_PostProcessing.sql

rem sqlcmd.exe -S%SQLServer% -E -otoptables.out -Q"set QUOTED_IDENTIFIER on; WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)  select distinct  stmt.stmt_details.value ('@Database', 'varchar(max)') 'Database' ,  stmt.stmt_details.value ('@Schema', 'varchar(max)') 'Schema' ,   stmt.stmt_details.value ('@Table', 'varchar(max)') 'table'  from (  select sqlplan from tempdb.dbo.tblPlansTemp) as p       cross apply sqlplan.nodes('//sp:Object') as stmt (stmt_details) "


@echo %date% %time% SQL Nexus PostProcessing complete +++


goto end

:usage
@echo %date% %time% Incorrect syntax. +++
@echo %date% %time% Proper usage:  %~n0 ServerName DatabaseName Filepath +++
endlocal
exit /b 1

:end
endlocal
exit /b 0